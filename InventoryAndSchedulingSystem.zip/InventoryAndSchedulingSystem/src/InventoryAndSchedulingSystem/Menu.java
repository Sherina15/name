package InventoryAndSchedulingSystem;

//import static InventoryAndSchedulingSystem.ViewAdminAccount.adminAccount_Table;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.ResultSetMetaData;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.Vector;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//import javax.swing.JOptionPane;
//import javax.swing.table.DefaultTableModel;
//import java.sql.Connection;

public class Menu extends javax.swing.JFrame {

    public Menu() 
    {
        initComponents(); 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        left_Panel = new javax.swing.JPanel();
        clientShop_Logo = new javax.swing.JLabel();
        clientShop_Name = new javax.swing.JLabel();
        home_Button = new javax.swing.JButton();
        list_Button = new javax.swing.JButton();
        inventory_Button = new javax.swing.JButton();
        schedule_Button = new javax.swing.JButton();
        productList_Button = new javax.swing.JButton();
        exit_Button = new javax.swing.JButton();
        top_Panel = new javax.swing.JPanel();
        home_Label = new javax.swing.JLabel();
        menu_TabbedPane = new javax.swing.JTabbedPane();
        home_Panel = new javax.swing.JPanel();
        logoutHome_Icon = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        inventory_Panel = new javax.swing.JPanel();
        viewProduct_Button = new javax.swing.JButton();
        addProduct_Button = new javax.swing.JButton();
        editProduct_Button = new javax.swing.JButton();
        inventoryReport_Button = new javax.swing.JButton();
        logoutInventory_Icon = new javax.swing.JLabel();
        schedule_Panel = new javax.swing.JPanel();
        viewSchedule_Button = new javax.swing.JButton();
        addSchedule_Button = new javax.swing.JButton();
        editSchedule_Button = new javax.swing.JButton();
        appointmentReport_Button = new javax.swing.JButton();
        logoutSchedule_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MENU");

        whole_Panel.setBackground(new java.awt.Color(0, 0, 0));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        left_Panel.setBackground(new java.awt.Color(255, 255, 255));
        left_Panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/2x2_client_logo.png"))); // NOI18N

        clientShop_Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        clientShop_Name.setText("DeTails Pet Essentials and Lodging");

        home_Button.setBackground(new java.awt.Color(204, 204, 204));
        home_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        home_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_home.png"))); // NOI18N
        home_Button.setText("Home");
        home_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        home_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                home_ButtonActionPerformed(evt);
            }
        });

        list_Button.setBackground(new java.awt.Color(204, 204, 204));
        list_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        list_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_accountlist.png"))); // NOI18N
        list_Button.setText("Admin Account");
        list_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        list_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                list_ButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                list_ButtonMouseEntered(evt);
            }
        });
        list_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                list_ButtonActionPerformed(evt);
            }
        });

        inventory_Button.setBackground(new java.awt.Color(204, 204, 204));
        inventory_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        inventory_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_inventory.png"))); // NOI18N
        inventory_Button.setText("Inventory ");
        inventory_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        inventory_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inventory_ButtonActionPerformed(evt);
            }
        });

        schedule_Button.setBackground(new java.awt.Color(204, 204, 204));
        schedule_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        schedule_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_calendar.png"))); // NOI18N
        schedule_Button.setText("   Schedule");
        schedule_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        schedule_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                schedule_ButtonActionPerformed(evt);
            }
        });

        productList_Button.setBackground(new java.awt.Color(204, 204, 204));
        productList_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        productList_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_list.png"))); // NOI18N
        productList_Button.setText("Product List");
        productList_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        productList_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productList_ButtonActionPerformed(evt);
            }
        });

        exit_Button.setBackground(new java.awt.Color(204, 204, 204));
        exit_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        exit_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_exit.png"))); // NOI18N
        exit_Button.setText("Exit");
        exit_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        exit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout left_PanelLayout = new javax.swing.GroupLayout(left_Panel);
        left_Panel.setLayout(left_PanelLayout);
        left_PanelLayout.setHorizontalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(left_PanelLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(clientShop_Logo)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(left_PanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(home_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(list_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(inventory_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(productList_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, left_PanelLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(clientShop_Name))
                            .addComponent(exit_Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(schedule_Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        left_PanelLayout.setVerticalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(clientShop_Logo)
                .addGap(18, 18, 18)
                .addComponent(clientShop_Name)
                .addGap(18, 18, 18)
                .addComponent(home_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(list_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(inventory_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(schedule_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(productList_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(exit_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        whole_Panel.add(left_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 630));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        home_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        home_Label.setForeground(new java.awt.Color(255, 255, 255));
        home_Label.setText("HOME");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(home_Label)
                .addContainerGap(436, Short.MAX_VALUE))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, top_PanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(home_Label)
                .addContainerGap())
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 0, 600, 100));

        menu_TabbedPane.setBackground(new java.awt.Color(255, 255, 255));

        home_Panel.setBackground(new java.awt.Color(255, 255, 255));

        logoutHome_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_logout.png"))); // NOI18N
        logoutHome_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutHome_IconMouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_facebook.png"))); // NOI18N
        jLabel1.setText("DeTails Pet Essentials and Lodging - Sabang");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_facebook.png"))); // NOI18N
        jLabel2.setText("DeTails San Rafael");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_phone.png"))); // NOI18N
        jLabel3.setText(" 09668764727");

        javax.swing.GroupLayout home_PanelLayout = new javax.swing.GroupLayout(home_Panel);
        home_Panel.setLayout(home_PanelLayout);
        home_PanelLayout.setHorizontalGroup(
            home_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(home_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(home_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(home_PanelLayout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(logoutHome_Icon))
                    .addGroup(home_PanelLayout.createSequentialGroup()
                        .addGroup(home_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(0, 264, Short.MAX_VALUE)))
                .addContainerGap())
        );
        home_PanelLayout.setVerticalGroup(
            home_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, home_PanelLayout.createSequentialGroup()
                .addContainerGap(407, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(home_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(logoutHome_Icon)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        menu_TabbedPane.addTab("Home", home_Panel);

        inventory_Panel.setBackground(new java.awt.Color(255, 255, 255));

        viewProduct_Button.setBackground(new java.awt.Color(204, 204, 204));
        viewProduct_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        viewProduct_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_view.png"))); // NOI18N
        viewProduct_Button.setText("View Product");
        viewProduct_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        viewProduct_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewProduct_ButtonActionPerformed(evt);
            }
        });

        addProduct_Button.setBackground(new java.awt.Color(204, 204, 204));
        addProduct_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        addProduct_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_add.png"))); // NOI18N
        addProduct_Button.setText("Add Product");
        addProduct_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        addProduct_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addProduct_ButtonActionPerformed(evt);
            }
        });

        editProduct_Button.setBackground(new java.awt.Color(204, 204, 204));
        editProduct_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        editProduct_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_refresh.png"))); // NOI18N
        editProduct_Button.setText("Edit Product");
        editProduct_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        editProduct_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editProduct_ButtonActionPerformed(evt);
            }
        });

        inventoryReport_Button.setBackground(new java.awt.Color(204, 204, 204));
        inventoryReport_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        inventoryReport_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_report.png"))); // NOI18N
        inventoryReport_Button.setText("Inventory Report");
        inventoryReport_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        inventoryReport_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inventoryReport_ButtonActionPerformed(evt);
            }
        });

        logoutInventory_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_logout.png"))); // NOI18N
        logoutInventory_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutInventory_IconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout inventory_PanelLayout = new javax.swing.GroupLayout(inventory_Panel);
        inventory_Panel.setLayout(inventory_PanelLayout);
        inventory_PanelLayout.setHorizontalGroup(
            inventory_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inventory_PanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logoutInventory_Icon)
                .addContainerGap())
            .addGroup(inventory_PanelLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(inventory_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inventory_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(editProduct_Button, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(addProduct_Button, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                        .addComponent(viewProduct_Button, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(inventoryReport_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(315, Short.MAX_VALUE))
        );
        inventory_PanelLayout.setVerticalGroup(
            inventory_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inventory_PanelLayout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(viewProduct_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(addProduct_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(editProduct_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(inventoryReport_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 183, Short.MAX_VALUE)
                .addComponent(logoutInventory_Icon)
                .addContainerGap())
        );

        menu_TabbedPane.addTab("Inventory", inventory_Panel);

        schedule_Panel.setBackground(new java.awt.Color(255, 255, 255));
        schedule_Panel.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), new javax.swing.border.MatteBorder(null)));

        viewSchedule_Button.setBackground(new java.awt.Color(204, 204, 204));
        viewSchedule_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        viewSchedule_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_view.png"))); // NOI18N
        viewSchedule_Button.setText("View Schedule");
        viewSchedule_Button.setToolTipText("Click to view schedule");
        viewSchedule_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        viewSchedule_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewSchedule_ButtonActionPerformed(evt);
            }
        });

        addSchedule_Button.setBackground(new java.awt.Color(204, 204, 204));
        addSchedule_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        addSchedule_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_add.png"))); // NOI18N
        addSchedule_Button.setText("Add Schedule");
        addSchedule_Button.setToolTipText("Click to add schedule");
        addSchedule_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        addSchedule_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addSchedule_ButtonActionPerformed(evt);
            }
        });

        editSchedule_Button.setBackground(new java.awt.Color(204, 204, 204));
        editSchedule_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        editSchedule_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_refresh.png"))); // NOI18N
        editSchedule_Button.setText("Edit Schedule");
        editSchedule_Button.setToolTipText("Click to edit schedule");
        editSchedule_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        editSchedule_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editSchedule_ButtonActionPerformed(evt);
            }
        });

        appointmentReport_Button.setBackground(new java.awt.Color(204, 204, 204));
        appointmentReport_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        appointmentReport_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_report.png"))); // NOI18N
        appointmentReport_Button.setText("Appointment Report");
        appointmentReport_Button.setToolTipText("Click to see appointment report");
        appointmentReport_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        appointmentReport_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                appointmentReport_ButtonActionPerformed(evt);
            }
        });

        logoutSchedule_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_logout.png"))); // NOI18N
        logoutSchedule_Icon.setToolTipText("Click to logout");
        logoutSchedule_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutSchedule_IconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout schedule_PanelLayout = new javax.swing.GroupLayout(schedule_Panel);
        schedule_Panel.setLayout(schedule_PanelLayout);
        schedule_PanelLayout.setHorizontalGroup(
            schedule_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(schedule_PanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logoutSchedule_Icon)
                .addContainerGap())
            .addGroup(schedule_PanelLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(schedule_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(schedule_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(viewSchedule_Button, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(addSchedule_Button, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                        .addComponent(editSchedule_Button, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(appointmentReport_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 272, Short.MAX_VALUE))
        );
        schedule_PanelLayout.setVerticalGroup(
            schedule_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(schedule_PanelLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(viewSchedule_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(addSchedule_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(editSchedule_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(appointmentReport_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 192, Short.MAX_VALUE)
                .addComponent(logoutSchedule_Icon)
                .addContainerGap())
        );

        menu_TabbedPane.addTab("Schedule", schedule_Panel);

        whole_Panel.add(menu_TabbedPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, 600, 570));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void list_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_list_ButtonActionPerformed
        ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
        viewAdminAccountModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_list_ButtonActionPerformed

    private void inventory_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inventory_ButtonActionPerformed
        menu_TabbedPane.setSelectedIndex(1);
    }//GEN-LAST:event_inventory_ButtonActionPerformed

    private void schedule_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_schedule_ButtonActionPerformed
        menu_TabbedPane.setSelectedIndex(2);
    }//GEN-LAST:event_schedule_ButtonActionPerformed

    private void productList_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productList_ButtonActionPerformed
        ProductList producListModule = new ProductList();
        producListModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_productList_ButtonActionPerformed

    private void exit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_ButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exit_ButtonActionPerformed

    private void logoutHome_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutHome_IconMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_logoutHome_IconMouseClicked

    private void home_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_home_ButtonActionPerformed
        menu_TabbedPane.setSelectedIndex(0);
    }//GEN-LAST:event_home_ButtonActionPerformed

    private void viewProduct_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewProduct_ButtonActionPerformed
        ViewProduct viewProductModule = new ViewProduct();
        viewProductModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_viewProduct_ButtonActionPerformed

    private void addProduct_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProduct_ButtonActionPerformed
        AddProduct addProductModule = new AddProduct();
        addProductModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_addProduct_ButtonActionPerformed

    private void editProduct_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editProduct_ButtonActionPerformed
       EditProduct editProductModule = new EditProduct();
       editProductModule.setVisible(true);
       dispose();         
    }//GEN-LAST:event_editProduct_ButtonActionPerformed

    private void inventoryReport_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inventoryReport_ButtonActionPerformed
        InventoryReport inventoryReportModule = new InventoryReport();
        inventoryReportModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_inventoryReport_ButtonActionPerformed

    private void logoutInventory_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutInventory_IconMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_logoutInventory_IconMouseClicked

    private void logoutSchedule_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutSchedule_IconMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_logoutSchedule_IconMouseClicked

    private void appointmentReport_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_appointmentReport_ButtonActionPerformed
        AppointmentReport appointmentReportModule = new  AppointmentReport();
        appointmentReportModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_appointmentReport_ButtonActionPerformed

    private void editSchedule_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editSchedule_ButtonActionPerformed
        EditSchedule editScheduleModule = new EditSchedule();
        editScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_editSchedule_ButtonActionPerformed

    private void addSchedule_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addSchedule_ButtonActionPerformed
        AddSchedule addScheduleModule = new AddSchedule();
        addScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_addSchedule_ButtonActionPerformed

    private void viewSchedule_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewSchedule_ButtonActionPerformed
        ViewSchedule viewScheduleModule = new ViewSchedule();
        viewScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_viewSchedule_ButtonActionPerformed

    private void list_ButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_list_ButtonMouseClicked
       
    }//GEN-LAST:event_list_ButtonMouseClicked

    private void list_ButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_list_ButtonMouseEntered
      
    }//GEN-LAST:event_list_ButtonMouseEntered


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addProduct_Button;
    private javax.swing.JButton addSchedule_Button;
    private javax.swing.JButton appointmentReport_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel clientShop_Name;
    private javax.swing.JButton editProduct_Button;
    private javax.swing.JButton editSchedule_Button;
    private javax.swing.JButton exit_Button;
    private javax.swing.JButton home_Button;
    private javax.swing.JLabel home_Label;
    private javax.swing.JPanel home_Panel;
    private javax.swing.JButton inventoryReport_Button;
    private javax.swing.JButton inventory_Button;
    private javax.swing.JPanel inventory_Panel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel left_Panel;
    private javax.swing.JButton list_Button;
    private javax.swing.JLabel logoutHome_Icon;
    private javax.swing.JLabel logoutInventory_Icon;
    private javax.swing.JLabel logoutSchedule_Icon;
    public static javax.swing.JTabbedPane menu_TabbedPane;
    private javax.swing.JButton productList_Button;
    private javax.swing.JButton schedule_Button;
    private javax.swing.JPanel schedule_Panel;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JButton viewProduct_Button;
    private javax.swing.JButton viewSchedule_Button;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
