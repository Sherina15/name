package InventoryAndSchedulingSystem;

public class EditProduct extends javax.swing.JFrame {

    public EditProduct() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        clientShop_Logo = new javax.swing.JLabel();
        editProduct_Label = new javax.swing.JLabel();
        editProduct_ScrollPane = new javax.swing.JScrollPane();
        editProduct_Table = new javax.swing.JTable();
        productNo_Label = new javax.swing.JLabel();
        productNo_TextField = new javax.swing.JTextField();
        productName_Label = new javax.swing.JLabel();
        productName_TextField = new javax.swing.JTextField();
        quantity_Label = new javax.swing.JLabel();
        quantity_Spinner = new javax.swing.JSpinner();
        category_Label = new javax.swing.JLabel();
        category_ComboBox = new javax.swing.JComboBox<>();
        editProduct_Button = new javax.swing.JButton();
        logout_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("EDIT PRODUCT");

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setPreferredSize(new java.awt.Dimension(850, 597));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        editProduct_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        editProduct_Label.setForeground(new java.awt.Color(255, 255, 255));
        editProduct_Label.setText("Edit Product");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addComponent(editProduct_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 558, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addContainerGap())
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clientShop_Logo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(editProduct_Label)
                        .addGap(0, 3, Short.MAX_VALUE)))
                .addContainerGap())
        );

        editProduct_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Product No.", "Product Name", "Quantity", "Category"
            }
        ));
        editProduct_ScrollPane.setViewportView(editProduct_Table);

        productNo_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        productNo_Label.setText("Product No.");

        productName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        productName_Label.setText("Product Name");

        quantity_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        quantity_Label.setText("Quantity");

        category_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        category_Label.setText("Category");

        category_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        editProduct_Button.setText("Update");
        editProduct_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editProduct_ButtonActionPerformed(evt);
            }
        });

        logout_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_exit.png"))); // NOI18N
        logout_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout_IconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, whole_PanelLayout.createSequentialGroup()
                        .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(productName_Label)
                                .addComponent(productName_TextField)
                                .addComponent(quantity_Label)
                                .addComponent(category_Label)
                                .addComponent(category_ComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(quantity_Spinner)
                                .addComponent(productNo_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(productNo_Label)
                            .addComponent(editProduct_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(editProduct_ScrollPane))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, whole_PanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(logout_Icon)))
                .addContainerGap())
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(editProduct_ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addComponent(productNo_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(productNo_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(productName_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(productName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(quantity_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(quantity_Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(category_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(category_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(editProduct_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(logout_Icon)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        Menu menuModule = new Menu();
        
        menuModule.menu_TabbedPane.setSelectedIndex(1);
        menuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void editProduct_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editProduct_ButtonActionPerformed
        UpdateProduct updateProductModule = new UpdateProduct();
        updateProductModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_editProduct_ButtonActionPerformed

    private void logout_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout_IconMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_logout_IconMouseClicked

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditProduct().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JComboBox<String> category_ComboBox;
    private javax.swing.JLabel category_Label;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JButton editProduct_Button;
    private javax.swing.JLabel editProduct_Label;
    private javax.swing.JScrollPane editProduct_ScrollPane;
    private javax.swing.JTable editProduct_Table;
    private javax.swing.JLabel logout_Icon;
    private javax.swing.JLabel productName_Label;
    private javax.swing.JTextField productName_TextField;
    private javax.swing.JLabel productNo_Label;
    private javax.swing.JTextField productNo_TextField;
    private javax.swing.JLabel quantity_Label;
    private javax.swing.JSpinner quantity_Spinner;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
